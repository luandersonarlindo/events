package br.com.nlw.events.dto;

public record ErrorMessage(String message) {
}
