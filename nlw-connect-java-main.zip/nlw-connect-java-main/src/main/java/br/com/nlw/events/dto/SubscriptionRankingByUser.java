package br.com.nlw.events.dto;

public record SubscriptionRankingByUser(SubscriptionRankingItem item, Integer position) {
}
