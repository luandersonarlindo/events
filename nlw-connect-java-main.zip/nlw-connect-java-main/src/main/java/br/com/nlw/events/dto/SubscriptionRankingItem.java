package br.com.nlw.events.dto;

public record SubscriptionRankingItem(Long subscribers, Integer userId, String name) {
}
