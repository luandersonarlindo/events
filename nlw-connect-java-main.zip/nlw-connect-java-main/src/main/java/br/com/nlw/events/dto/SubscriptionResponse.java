package br.com.nlw.events.dto;

public record SubscriptionResponse(Integer subscriptionNumber, String designation) {
}
