package br.com.nlw.events.exception;

public class UserIndicadorNotFoundException extends RuntimeException {
    public UserIndicadorNotFoundException(String msg) {
        super(msg);
    }

}
